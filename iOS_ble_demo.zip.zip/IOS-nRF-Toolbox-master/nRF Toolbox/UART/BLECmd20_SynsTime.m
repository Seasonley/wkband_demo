//
//  BLECmd21_SynsTime.m
//  nRF Toolbox
//
//  Created by 迈诺科技 on 15/12/22.
//  Copyright © 2015年 Nordic Semiconductor. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BLECmd20_SynsTime.h"
//
//@implementation BLECmd20_SynsTime
//
//- (NSDate *)synsCurTime {
//    UInt32 seconds = (UInt32)[[NSDate date] timeIntervalSince1970] + [[NSTimeZone systemTimeZone] secondsFromGMT];
//    
//    Byte time[4];
//    
//    time[0] = (seconds & 0xff);
//    time[1] = ((seconds >> 8) & 0xff);
//    time[2] = ((seconds >> 16) & 0xff);
//    time[3] = ((seconds >> 24) & 0xff);
//    
//    return [self send_frame:TimeSync_Enum withData:time withLen:4];
//}
//
//- (void)deal

//@end