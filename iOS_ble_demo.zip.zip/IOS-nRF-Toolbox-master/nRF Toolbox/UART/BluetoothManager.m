/*
 * Copyright (c) 2015, Nordic Semiconductor
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#import "BluetoothManager.h"
#import "Constants.h"
#import "UARTViewController.h"

@implementation BluetoothManager

+ (id)sharedInstance
{
    static BluetoothManager *sharedInstance = nil;
    static dispatch_once_t oncePredicate;
    dispatch_once(&oncePredicate, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

-(id)init
{
    if (self = [super init]) {
        self.UART_Service_UUID = [CBUUID UUIDWithString:uartServiceUUIDString];
        self.UART_TX_Characteristic_UUID = [CBUUID UUIDWithString:uartTXCharacteristicUUIDString];
        self.UART_RX_Characteristic_UUID = [CBUUID UUIDWithString:uartRXCharacteristicUUIDString];
    }
    return self;
}

-(void)setUARTDelegate:(id<BluetoothManagerDelegate>)uartDelegate
{
    self.uartDelegate = uartDelegate;
}

-(void)setLogDelegate:(id<BluetoothManagerDelegate>)logDelegate
{
    self.logDelegate = logDelegate;
}

-(void)setBluetoothCentralManager:(CBCentralManager *)manager
{
    if (manager) {
        self.centralManager = manager;
        self.centralManager.delegate = self;
    }
}

-(void)connectDevice:(CBPeripheral *)peripheral
{
    if (peripheral) {
        self.bluetoothPeripheral = peripheral;
        self.bluetoothPeripheral.delegate = self;
        [self.centralManager connectPeripheral:peripheral options:nil];
    }
}

-(void)disconnectDevice
{
    if (self.bluetoothPeripheral) {
        [self.centralManager cancelPeripheralConnection:self.bluetoothPeripheral];
    }
}

-(void)writeRXValue:(NSString *)value
{
    if (self.uartRXCharacteristic) {
        NSLog(@"writing command: %@ to UART peripheral: %@",value,self.bluetoothPeripheral.name);
        [self.bluetoothPeripheral writeValue:[value dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.uartRXCharacteristic type:CBCharacteristicWriteWithoutResponse];
    }
}

#pragma mark - CentralManager delegates
- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    NSLog(@"centralManagerDidUpdateState");
}

-(void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    NSLog(@"didConnectPeripheral");
    [self.uartDelegate didDeviceConnected:peripheral.name];
    [self.bluetoothPeripheral discoverServices:nil];
}

-(void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"didDisconnectPeripheral");
    [self.uartDelegate didDeviceDisconnected];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"CBPeripheralDisconnectNotification" object:self];
    self.bluetoothPeripheral = nil;
}

-(void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"didFailToConnectPeripheral");
    [self.uartDelegate didDeviceDisconnected];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"CBPeripheralDisconnectNotification" object:self];
    self.bluetoothPeripheral = nil;
}

#pragma mark Peripheral delegate methods

-(void) peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    NSLog(@"didDiscoverServices");
    if (!error) {
        NSLog(@"services discovered %lu",(unsigned long)[peripheral.services count] );
        for (CBService *uartService in peripheral.services) {
            NSLog(@"service discovered: %@",uartService.UUID);
            if ([uartService.UUID isEqual:self.UART_Service_UUID])
            {
                NSLog(@"UART service found");
                [self.uartDelegate didDiscoverUARTService:uartService];
                [self.bluetoothPeripheral discoverCharacteristics:nil forService:uartService];
            }
        }
    } else {
        NSLog(@"error in discovering services on device: %@",self.bluetoothPeripheral.name);
    }
}

-(void) peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    if (!error) {
        if ([service.UUID isEqual:self.UART_Service_UUID]) {
            for (CBCharacteristic *characteristic in service.characteristics)
            {
                if ([characteristic.UUID isEqual:self.UART_TX_Characteristic_UUID]) {
                    NSLog(@"UART TX characteritsic is found");
                    [self.uartDelegate didDiscoverTXCharacteristic:characteristic];
                    //使能notify
                    [self.bluetoothPeripheral setNotifyValue:YES forCharacteristic:characteristic ];
                    
                    //[self performSelector:@selector(syncTime) withObject:nil afterDelay:0.1f];
                }
                else if ([characteristic.UUID isEqual:self.UART_RX_Characteristic_UUID]) {
                    NSLog(@"UART RX characteristic is found");
                    [self.uartDelegate didDiscoverRXCharacteristic:characteristic];
                    self.uartRXCharacteristic = characteristic;
                    [self syncTime];
                    [self getPower];
                    [self getattention:1];
                    [self getattention:2];
                    [self getattention:3];
                }
            }
        }
        
    } else {
        NSLog(@"error in discovering characteristic on device: %@",self.bluetoothPeripheral.name);
    }
}

-(void) peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (!error) {
        NSLog(@"received update after Async: %@, UUID: %@",characteristic.value,characteristic.UUID);
        if (characteristic.value.length != 0) {
            //NSData *notifyData = [characteristic value];
            Byte *notifydata = (Byte *)[characteristic.value bytes];
            //[self.uartDelegate didReceiveTXNotification:characteristic.value];
            //[[NSNotificationCenter defaultCenter] postNotificationName:@"CBPeripheralTXNotification" object:self];
            if(*notifydata == 0x68)
            {
                Byte ctrl = *(notifydata+1) & 0x7f;
                switch (ctrl) {
                    case 0x03:
                    {
                        int power = *(notifydata+4);
                        NSLog(@"电量 %d", power);
                        break;
                    }
                    case 0x05:
                    {
                        //读取提醒开关
                        Byte type = *(notifydata+4);
                        if(type == 0x00)
                        {
                            break;
                        }
                        int attention_type = *(notifydata+5);
                        Byte onoff = *(notifydata+6);
                        switch (attention_type)
                        {
                        case 1:
                        {
                            NSLog(@"防丢 %02x", onoff);
                            if(onoff == 0x01)
                            {
                                [self.UARVC.fangdiuSwitch setOn:YES];
                            }
                            else{
                                [self.UARVC.fangdiuSwitch setOn:NO];
                            }
                            break;
                        }
                        case 2:
                        {
                            NSLog(@"短信 %02x", onoff);
                            if(onoff == 0x01)
                            {
                                [self.UARVC.duanxinSwith setOn:YES];
                            }
                            else{
                                [self.UARVC.duanxinSwith setOn:NO];
                            }
                            break;
                        }
                        case 3:
                        {
                            NSLog(@"电话 %02x", onoff);
                            if(onoff == 0x01) {
                                [self.UARVC.dianhuaSwith setOn:YES];
                            }
                            else {
                                [self.UARVC.dianhuaSwith setOn:NO];
                            }
                            break;
                        }
                        default:
                            break;
                        }
                        
                    }
                    case 0x20:
                    {
                        //校时
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
        }
    }
    else {
        NSLog(@"error in update UART value");
    }
}

- (void)updatehardwaerComplete
{
    Byte transData[] = {0x68,0x08,0x01,0x00,0x02};
    uint checkNum = 0;
    for (int i = 0 ; i < sizeof(transData); i ++)
    {
        checkNum += transData[i];
    }
    checkNum = checkNum%256;
    Byte tempData[] = {checkNum, 0x16};
    NSMutableData *lData = [[NSMutableData alloc]init];
    [lData appendBytes:transData length:sizeof(transData)];
    [lData appendBytes:tempData length:sizeof(tempData)];
    NSLog(@"%@",lData);
    /*
    [self.bluetoothPeripheral writeValue:lData forCharacteristic:self.uartRXCharacteristic type:CBCharacteristicWriteWithoutResponse];
     */
    //[cbPeripheral writeValue:lData forCharacteristic:rdCharactic1 type:CBCharacteristicWriteWithResponse];
}

-(Byte)calCS:(Byte *)data withLen:(int)len
{
    UInt32 i, cs = 0;
    
    for(i = 0; i < len; i++)
    {
        cs += data[i];
    }
    
    return (Byte)cs;
}

- (void)syncTime
{
    UInt32 seconds = (UInt32)[[NSDate date] timeIntervalSince1970] + [[NSTimeZone systemTimeZone] secondsFromGMT];
#if 1
    uint checkNum = 0x68 + TimeSync_Enum + (seconds & 255) + ((seconds >> 8) & 255) + ((seconds >> 16)& 255) + ((seconds >> 24)& 255) + 0x04;
    checkNum = checkNum % 256;
    Byte transData[] = {0x68, TimeSync_Enum, 0x04, 0x00, seconds,seconds >> 8,seconds >> 16,seconds >> 24,checkNum, 0x16};
    NSData *lData = [NSData dataWithBytes:transData length:sizeof(transData)];
    //if (rdCharactic1)
    {
        [self.bluetoothPeripheral writeValue:lData forCharacteristic:self.uartRXCharacteristic type:CBCharacteristicWriteWithResponse];
        //NSData *lData = [NSData dataWithBytes:transData length:ArraySize(transData)];
        //[cbPeripheral writeValue:lData forCharacteristic:self.uartRXCharacteristic type:CBCharacteristicWriteWithResponse];
    }

//
#else
    
#endif
    //[cbPeripheral writeValue:lData forCharacteristic:rdCharactic1 type:CBCharacteristicWriteWithResponse];
}

- (void) getattention:(int)type
{
    Byte transData[8] = {0x68, 0x05, 0x02, 0x00, 0x01};
    
    transData[5] = type;
    
    transData[6] = [self calCS:transData withLen:6];
    transData[7] = 0x16;
    
    NSData *lData = [NSData dataWithBytes:transData length:sizeof(transData)];
    
    [self.bluetoothPeripheral writeValue:lData forCharacteristic:self.uartRXCharacteristic type:CBCharacteristicWriteWithResponse];
}

- (void) setattention:(int)type setflag:(int)flag
{
    Byte transData[9] = {0x68, 0x05, 0x03, 0x00, 0x00};
    
    transData[5] = type;
    transData[6] = flag;
    
    transData[7] = [self calCS:transData withLen:7];
    transData[8] = 0x16;
    
    NSData *lData = [NSData dataWithBytes:transData length:sizeof(transData)];
    
    [self.bluetoothPeripheral writeValue:lData forCharacteristic:self.uartRXCharacteristic type:CBCharacteristicWriteWithResponse];

}

- (void) getPower
{
    Byte transData[6] = {0x68, 0x03, 0x00, 0x00, 0x00, 0x16};
    
    transData[4] = [self calCS:transData withLen:4];
    
    NSData *lData = [NSData dataWithBytes:transData length:sizeof(transData)];
    
    [self.bluetoothPeripheral writeValue:lData forCharacteristic:self.uartRXCharacteristic type:CBCharacteristicWriteWithResponse];
}
@end
