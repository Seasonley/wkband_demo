//
//  BLEBase.m
//  nRF Toolbox
//
//  Created by 迈诺科技 on 15/12/22.
//  Copyright © 2015年 Nordic Semiconductor. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BLEBase.h"
#import "Constants.h"

@implementation BLEBase

-(Byte)calCS:(Byte *)data withLen:(int)len {
    int cs = 0;
    for(int i = 0; i < len; i++) {
        cs = cs + data[i];
    }
    return (Byte)(cs & 0xff);
}
//
//-(NSDate *)send_frame:(Byte)cmd withData:(NSDate *)data withLen:(int)len {
//    int idx = 0;
//    int len_tmp;
//    //NSDate *frame = nex;
//    
//    frame[idx++] = 0x68;
//    frame[idx++] = cmd;
//    frame[idx++] = (Byte)(len & 0xff);
//    frame[idx++] = (Byte)((len >> 8) & 0xff);
//    for(int i = 0; i < len; i++)
//    {
//        frame[idx++] = data[i];
//    }
//    
//    len_tmp = idx;
//    frame[idx++] = [self calCS:frame withLen:len_tmp];
//    frame[idx++] = 0x16;
//    
//    return frame;
//}

@end