//
//  BLECmd20_SynsTime.h
//  nRF Toolbox
//
//  Created by 迈诺科技 on 15/12/22.
//  Copyright © 2015年 Nordic Semiconductor. All rights reserved.
//

#ifndef BLECmd20_SynsTime_h
#define BLECmd20_SynsTime_h

//@interface BLECmd20_SynsTime : BLEBase

//@end

#endif /* BLECmd20_SynsTime_h */
