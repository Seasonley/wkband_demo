//
//  BLEBase.h
//  nRF Toolbox
//
//  Created by 迈诺科技 on 15/12/22.
//  Copyright © 2015年 Nordic Semiconductor. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BLEBase : NSObject

-(Byte)calCS:(Byte *)data withLen:(int)len;
-(NSDate *)send_frame:(Byte)cmd withData:(NSDate *)data withLen:(int)len;

@end
