//
//  BLE.c
//  nRF Toolbox
//
//  Created by 迈诺科技 on 15/12/22.
//  Copyright © 2015年 Nordic Semiconductor. All rights reserved.
//

#include "BLE.h"
